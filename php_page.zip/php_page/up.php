<!DOCTYPE HTML>
<html>
<style>
body{
background-image:url(z.png);
background-attachment: fixed;
text-align: center;
font-size: 30px;
font-family:arial;
}
</style>
<body>
<?php


echo "UP";

?>

</body>
</html>
